import { Star, MapPin, Users, Wifi, Coffee, Car } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

const hotels = [
  {
    name: 'Cinnamon Grand Colombo',
    location: 'Colombo',
    rating: 4.8,
    reviews: 1234,
    price: 180,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500',
    amenities: ['WiFi', 'Pool', 'Spa', 'Restaurant'],
  },
  {
    name: 'Heritance Kandalama',
    location: 'Dambulla',
    rating: 4.9,
    reviews: 856,
    price: 220,
    image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=500',
    amenities: ['WiFi', 'Pool', 'Gym', 'Restaurant'],
  },
  {
    name: 'Anantara Peace Haven',
    location: 'Tangalle',
    rating: 4.7,
    reviews: 643,
    price: 350,
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=500',
    amenities: ['WiFi', 'Beach', 'Spa', 'Restaurant'],
  },
];

const tourPackages = [
  {
    name: 'Cultural Triangle Explorer',
    duration: '7 Days',
    price: 899,
    rating: 4.8,
    reviews: 234,
    image: 'https://images.unsplash.com/photo-1663784025074-49e9e7f11f62?w=500',
    includes: ['Accommodation', 'Transport', 'Guide', 'Breakfast'],
  },
  {
    name: 'Beach & Wildlife Combo',
    duration: '5 Days',
    price: 749,
    rating: 4.7,
    reviews: 189,
    image: 'https://images.unsplash.com/photo-1589534345827-e619f9b2dd2b?w=500',
    includes: ['Accommodation', 'Safari', 'Meals', 'Transport'],
  },
  {
    name: 'Tea Country Adventure',
    duration: '4 Days',
    price: 599,
    rating: 4.9,
    reviews: 312,
    image: 'https://images.unsplash.com/photo-1559038300-07cb5d6c3d27?w=500',
    includes: ['Accommodation', 'Tea Tours', 'Hiking', 'Meals'],
  },
];

const vehicles = [
  {
    type: 'Luxury SUV',
    capacity: '4-6 passengers',
    price: 80,
    image: 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=500',
    features: ['AC', 'WiFi', 'English Driver'],
  },
  {
    type: 'Van',
    capacity: '8-12 passengers',
    price: 120,
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=500',
    features: ['AC', 'WiFi', 'Luggage Space'],
  },
];

export default function Bookings() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-secondary py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl text-white mb-4">
            Book Your Experience
          </h1>
          <p className="text-xl text-white/90">
            Hotels, tours, and transportation - all in one place
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="hotels" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-8">
            <TabsTrigger value="hotels">Hotels</TabsTrigger>
            <TabsTrigger value="packages">Tour Packages</TabsTrigger>
            <TabsTrigger value="transport">Transport</TabsTrigger>
          </TabsList>

          {/* Hotels Tab */}
          <TabsContent value="hotels">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {hotels.map((hotel, index) => (
                <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all">
                  <img src={hotel.image} alt={hotel.name} className="w-full h-48 object-cover" />
                  <div className="p-5">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-xl text-gray-900">{hotel.name}</h3>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{hotel.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600 text-sm mb-4">
                      <MapPin className="w-4 h-4" />
                      <span>{hotel.location}</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {hotel.amenities.map((amenity) => (
                        <Badge key={amenity} variant="secondary">{amenity}</Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <span className="text-2xl text-primary">${hotel.price}</span>
                        <span className="text-sm text-gray-500">/night</span>
                      </div>
                      <Button>Book Now</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Packages Tab */}
          <TabsContent value="packages">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tourPackages.map((pkg, index) => (
                <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all">
                  <img src={pkg.image} alt={pkg.name} className="w-full h-48 object-cover" />
                  <div className="p-5">
                    <h3 className="text-xl text-gray-900 mb-2">{pkg.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">{pkg.duration}</p>
                    <div className="space-y-2 mb-4">
                      {pkg.includes.map((item) => (
                        <div key={item} className="flex items-center gap-2 text-sm text-gray-700">
                          <div className="w-1.5 h-1.5 bg-secondary rounded-full"></div>
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <span className="text-2xl text-primary">${pkg.price}</span>
                        <span className="text-sm text-gray-500">/person</span>
                      </div>
                      <Button>View Details</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Transport Tab */}
          <TabsContent value="transport">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vehicles.map((vehicle, index) => (
                <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all">
                  <img src={vehicle.image} alt={vehicle.type} className="w-full h-48 object-cover" />
                  <div className="p-5">
                    <h3 className="text-xl text-gray-900 mb-2">{vehicle.type}</h3>
                    <div className="flex items-center gap-2 text-gray-600 text-sm mb-4">
                      <Users className="w-4 h-4" />
                      <span>{vehicle.capacity}</span>
                    </div>
                    <div className="space-y-2 mb-4">
                      {vehicle.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2 text-sm text-gray-700">
                          <div className="w-1.5 h-1.5 bg-secondary rounded-full"></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div>
                        <span className="text-2xl text-primary">${vehicle.price}</span>
                        <span className="text-sm text-gray-500">/day</span>
                      </div>
                      <Button>Book Now</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
