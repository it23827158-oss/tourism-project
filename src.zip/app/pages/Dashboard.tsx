import { Calendar, MapPin, Heart, Clock, User, Settings } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

const savedTrips = [
  { name: 'Summer Adventure 2026', destinations: 5, days: 7, status: 'Planning' },
  { name: 'Cultural Heritage Tour', destinations: 4, days: 5, status: 'Saved' },
];

const bookings = [
  {
    type: 'Hotel',
    name: 'Cinnamon Grand Colombo',
    date: 'Mar 15, 2026',
    status: 'Confirmed',
    price: 540,
  },
  {
    type: 'Tour',
    name: 'Cultural Triangle Explorer',
    date: 'Mar 16, 2026',
    status: 'Pending',
    price: 899,
  },
];

const favorites = [
  {
    name: 'Sigiriya Rock Fortress',
    type: 'Destination',
    image: 'https://images.unsplash.com/photo-1663784025074-49e9e7f11f62?w=300',
  },
  {
    name: 'Ella Hill Country',
    type: 'Destination',
    image: 'https://images.unsplash.com/photo-1759213111668-880a071ecf0f?w=300',
  },
  {
    name: 'Yala National Park',
    type: 'Destination',
    image: 'https://images.unsplash.com/photo-1705936981588-a4192f66fcfb?w=300',
  },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-secondary py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl text-white mb-1">Welcome back, Traveler!</h1>
              <p className="text-white/90">Manage your trips and bookings</p>
            </div>
            <Button variant="outline" className="ml-auto bg-white/10 border-white text-white hover:bg-white hover:text-primary">
              <Settings className="w-5 h-5 mr-2" />
              Settings
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <div className="flex items-center gap-3">
                <MapPin className="w-8 h-8 text-white" />
                <div>
                  <p className="text-2xl text-white">12</p>
                  <p className="text-sm text-white/80">Places Visited</p>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <div className="flex items-center gap-3">
                <Calendar className="w-8 h-8 text-white" />
                <div>
                  <p className="text-2xl text-white">3</p>
                  <p className="text-sm text-white/80">Upcoming Trips</p>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <div className="flex items-center gap-3">
                <Heart className="w-8 h-8 text-white" />
                <div>
                  <p className="text-2xl text-white">18</p>
                  <p className="text-sm text-white/80">Favorites</p>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <div className="flex items-center gap-3">
                <Clock className="w-8 h-8 text-white" />
                <div>
                  <p className="text-2xl text-white">45</p>
                  <p className="text-sm text-white/80">Days Traveled</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="trips" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-8">
            <TabsTrigger value="trips">My Trips</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>

          {/* Saved Trips Tab */}
          <TabsContent value="trips">
            <div className="space-y-4">
              {savedTrips.map((trip, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-md p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-xl text-gray-900 mb-2">{trip.name}</h3>
                      <div className="flex gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{trip.destinations} destinations</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{trip.days} days</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={trip.status === 'Planning' ? 'default' : 'secondary'}>
                        {trip.status}
                      </Badge>
                      <Button>View Trip</Button>
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full">
                Create New Trip Plan
              </Button>
            </div>
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings">
            <div className="space-y-4">
              {bookings.map((booking, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-md p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge variant="outline">{booking.type}</Badge>
                        <h3 className="text-xl text-gray-900">{booking.name}</h3>
                      </div>
                      <div className="flex gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{booking.date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-primary">${booking.price}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge
                        className={
                          booking.status === 'Confirmed'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-yellow-100 text-yellow-700'
                        }
                      >
                        {booking.status}
                      </Badge>
                      <Button variant="outline">View Details</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {favorites.map((item, index) => (
                <div
                  key={index}
                  className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all"
                >
                  <div className="relative">
                    <img src={item.image} alt={item.name} className="w-full h-48 object-cover" />
                    <Button
                      size="sm"
                      className="absolute top-4 right-4 bg-white/90 text-red-500 hover:bg-white"
                    >
                      <Heart className="w-4 h-4 fill-red-500" />
                    </Button>
                  </div>
                  <div className="p-4">
                    <Badge variant="secondary" className="mb-2">
                      {item.type}
                    </Badge>
                    <h3 className="text-lg text-gray-900">{item.name}</h3>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
