import { Link } from 'react-router';
import { MapPin, Star, Calendar } from 'lucide-react';
import { Badge } from './ui/badge';

interface DestinationCardProps {
  id: string;
  title: string;
  description: string;
  image: string;
  location: string;
  rating: number;
  reviews: number;
  bestSeason?: string;
  tags?: string[];
  featured?: boolean;
}

export default function DestinationCard({
  id,
  title,
  description,
  image,
  location,
  rating,
  reviews,
  bestSeason,
  tags,
  featured,
}: DestinationCardProps) {
  return (
    <Link to={`/destinations/${id}`}>
      <div className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
        {/* Image */}
        <div className="relative overflow-hidden aspect-[4/3]">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          {featured && (
            <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
              Featured
            </Badge>
          )}
          {tags && tags.length > 0 && (
            <div className="absolute top-4 right-4 flex gap-2">
              {tags.slice(0, 2).map((tag) => (
                <Badge key={tag} variant="secondary" className="bg-white/90 text-gray-800">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-5 flex-1 flex flex-col">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-xl text-gray-900 group-hover:text-primary transition-colors">
              {title}
            </h3>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm text-gray-900">{rating}</span>
              <span className="text-sm text-gray-500">({reviews})</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-gray-600 text-sm mb-3">
            <MapPin className="w-4 h-4" />
            <span>{location}</span>
          </div>

          <p className="text-gray-600 text-sm mb-4 line-clamp-2 flex-1">
            {description}
          </p>

          {bestSeason && (
            <div className="flex items-center gap-2 text-sm text-gray-500 pt-3 border-t border-gray-100">
              <Calendar className="w-4 h-4" />
              <span>Best time: {bestSeason}</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
