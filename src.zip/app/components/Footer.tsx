import { Link } from 'react-router';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import logo from 'figma:asset/7a68ca615fbfe06ed90f36e9d005a323eac2110c.png';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <img src={logo} alt="SL Traveler" className="h-12 w-auto mb-4 brightness-0 invert" />
            <p className="text-sm text-gray-400">
              Discover the beauty of Sri Lanka with personalized tours, expert guides, and unforgettable experiences.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/destinations" className="text-sm hover:text-white transition-colors">Destinations</Link></li>
              <li><Link to="/trip-planner" className="text-sm hover:text-white transition-colors">Trip Planner</Link></li>
              <li><Link to="/bookings" className="text-sm hover:text-white transition-colors">Bookings</Link></li>
              <li><Link to="/guides" className="text-sm hover:text-white transition-colors">Travel Guides</Link></li>
              <li><Link to="/map" className="text-sm hover:text-white transition-colors">Map & Services</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="text-sm hover:text-white transition-colors">FAQs</a></li>
              <li><a href="#" className="text-sm hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-sm hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-sm hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm">
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span>123 Beach Road, Colombo 03, Sri Lanka</span>
              </li>
              <li className="flex items-center gap-2 text-sm">
                <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                <span>+94 11 234 5678</span>
              </li>
              <li className="flex items-center gap-2 text-sm">
                <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                <span>hello@sltraveler.lk</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-400">
            © 2026 SL Traveler. All rights reserved.
          </p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <button className="text-sm text-gray-400 hover:text-white transition-colors">
              English
            </button>
            <button className="text-sm text-gray-400 hover:text-white transition-colors">
              සිංහල
            </button>
            <button className="text-sm text-gray-400 hover:text-white transition-colors">
              தமிழ்
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
